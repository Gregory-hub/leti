
using System;                // Console
using System.IO;             // FileStream, FileReader
    
class FileDetails 
{
    static void Main() 
	{
		/*
		FileStream stream = new FileStream(fileName, FileMode.Open);
        StreamReader reader = new StreamReader(stream); 
		*/
      
        //TODO: Add code here


    }
}
